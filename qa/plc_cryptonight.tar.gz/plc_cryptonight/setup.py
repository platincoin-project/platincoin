from distutils.core import setup, Extension

litecoin_scrypt_module = Extension('plc_cryptonight',
                               sources = ['plc-cryptonight/module.cpp',
                                          'plc-cryptonight/crypto/CryptoNight.cpp',
                                          'plc-cryptonight/crypto/c_jh.c',
                                          'plc-cryptonight/crypto/c_skein.c',
                                          'plc-cryptonight/crypto/c_keccak.c',
                                          'plc-cryptonight/crypto/c_groestl.c',
                                          'plc-cryptonight/crypto/c_blake256.c'],
                               include_dirs=['./plc-cryptonight/'],
                               extra_compile_args=['-maes'])

setup (
    name = 'plc_cryptonight',
    version = '1.0.1',
    description = 'Bindings for cryptonight proof of work used by Platincoin',
    classifiers=[
        'Intended Audience :: Developers',

        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
    ],
    ext_modules = [litecoin_scrypt_module]
)
