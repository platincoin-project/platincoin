#include <Python.h>

#include "crypto/CryptoNight.h"

/*
static PyObject *scrypt_getpowhash(PyObject *self, PyObject *args)
{
    char *output;
    PyObject *value;
    PyStringObject *input;
    if (!PyArg_ParseTuple(args, "S", &input))
        return NULL;
    Py_INCREF(input);
    output = PyMem_Malloc(32);

    scrypt_1024_1_1_256((char *)PyString_AsString((PyObject*) input), output);
    Py_DECREF(input);
    value = Py_BuildValue("s#", output, 32);
    PyMem_Free(output);
    return value;
}
*/

static PyObject *getpowhash(PyObject *self, PyObject *args, PyObject* kwargs) {
    char * input;
    int      inputlen;

    char * outbuf;
    size_t   outbuflen;

    static char *g2_kwlist[] = {"input", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "y#", g2_kwlist,
                                     &input, &inputlen)) {
        return NULL;
    }

    outbuf = (char *)PyMem_Malloc(32);
    outbuflen = 32;

    Py_BEGIN_ALLOW_THREADS;
    

    static scratchpad_memory scratchpad;
    scratchpad.hash(reinterpret_cast<void *>(input), inputlen, reinterpret_cast<void *>(outbuf));

    // scrypt_1024_1_1_256(input, outbuf);

    Py_END_ALLOW_THREADS;

    PyObject *value = NULL;
    
    value = Py_BuildValue("y#", outbuf, 32);
    
    PyMem_Free(outbuf);
    return value;
}


static PyMethodDef CryptoMethods[] = {
    { "getPoWHash", (PyCFunction) getpowhash, METH_VARARGS | METH_KEYWORDS, "Returns the proof of work hash using scrypt" },
    { NULL, NULL, 0, NULL }
};

static struct PyModuleDef cryptomodule = {
    PyModuleDef_HEAD_INIT,
    "plc_cryptonight",
    NULL,
    -1,
    CryptoMethods
};

PyMODINIT_FUNC PyInit_plc_cryptonight(void) {
    PyObject *m = PyModule_Create(&cryptomodule);

    if (m == NULL) {
        return NULL;
    }

    return m;
}